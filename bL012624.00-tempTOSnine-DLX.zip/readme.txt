
AllWebCo Templates
http://allwebco-templates.com/

AllWebCo Support Center
http://www.allwebco-templates.com/support/

--------------------------------------------------------------------------

Unzip the files onto your hard drive and be sure the "picts" directory
properly unzips into it's own directory. The same applies to the "gallery"
directory if your template has one.


To start the setup open the "help.html". It's best to be on-line
when opening the help.html because it looks for current info at AllWebCo.


The help.html contains:

1. Step by Step instructions
2. Links to contact AllWebCo
3. Template Options
4. Links to helpful websites
5. The most current info at AllWebCo

--------------------------------------------------------------------------

Thanks for choosing AllWebCo!