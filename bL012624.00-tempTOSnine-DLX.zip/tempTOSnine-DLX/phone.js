<!-- Begin

// NOTE: If you use a ' add a slash before it like this \'

document.write('<span class="phonetitle">');

document.write('Your Company Name');

document.write('</span><br>');

document.write('10901 Your Road Hwy. Suite 301<br>');

document.write('Chicago, IL 60060<br>');

document.write('PHONE: <span class="phonetitle">(555) 555-5555<BR></span>');

document.write('FAX: <span class="phonetitle">(555) 555-5555<BR></span>');

document.write('<BR>E-mail us: ');

document.write(' <A HREF="mailto:info@yourdomain.com">info@yourdomain.com</a><br>');


//  End -->