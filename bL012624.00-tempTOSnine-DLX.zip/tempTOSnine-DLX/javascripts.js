<!-- Begin

function blockError(){return true;}
window.onerror = blockError;

// -->