

SETUP INFORMATION CAN BE FOUND IN THE HELP.HTML


IMPORTANT: You must be on-line to open the help.html because it is linked
to the AllWebCo site to keep the instructions and help current.


For more templates and pre-made sites visit: http://allwebcodesign.com
For the best hosting on the planet visit: http://allwebco.com