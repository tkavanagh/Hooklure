<!-- Begin

// NOTE: If you use a ' add a slash before it like this \'

document.write('<TABLE cellpadding="0" cellspacing="0" border="0" width="100%"><tr><td align="center" width="50%">');

document.write('<form style="margin: 0px">');
document.write('<input type="button" value="Print" onClick=\'window.print()\' class="button-popups" onmouseover="this.className=\'buttonon-popups\'" onmouseout="this.className=\'button-popups\'"><br>');
document.write('</form>');

document.write('<td align="center" width="50%">');

document.write('<form style="margin: 0px">');
document.write('<input type="button" value="Close" onClick=\'window.close()\' class="button-popups" onmouseover="this.className=\'buttonon-popups\'" onmouseout="this.className=\'button-popups\'"><br>');
document.write('</form>');

document.write('</td></tr></table>');

//  End -->