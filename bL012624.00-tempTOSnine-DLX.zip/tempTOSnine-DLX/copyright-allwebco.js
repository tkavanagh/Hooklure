<!-- Begin

// NOTE: If you use a ' add a slash before it like this \'

// NOTE: For no allwebco copyright erase only the next 2 lines


document.write('<span class="copyright">');
document.write('<a href="http://allwebcodesign.com" target="_top">AllWebCo Design</a> & <a href="http://allwebco.com" target="_top">Hosting</a><br>&copy;Site Design 2006</span>');






document.write('<br>');




//  End -->